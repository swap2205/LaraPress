<?php

namespace Modules\CMS\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\Auth\MyTraits\GetDatatables;
use Modules\CMS\Entities\Page;
use Theme;
use Str;

class CMSController extends Controller
{

    /**
     * Display a listing of the resource.
     * @return Response
     */
    use GetDatatables;

    public function __construct()
    {
        $this->theme = Theme::uses('admin');
    }
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index(Page $page)
    {
        return($page);
        return view('cms::index');
    }

    // admin controller - starts
    public function list($type='page')
    {
        // dd(Page::$form_fields);
        $data['page_type'] = $type;
        $formdata = Page::$form_fields;
        $formdata['parent_id']['values'] = array_column(
            json_decode(
                Page::select('id','title')->where('page_type',$type)->get()
                ,1
            ),
            'title','id');
        // return($formdata);
        $data['form_fields'] = crud_form_generator($formdata);
        $this->theme->setTitle(Str::of($type)->plural()->title());
        $this->theme->asset()->serve('datatables');
        // return $this->theme->of('cms::index',$data)->render();
        return $this->theme->of('cms::page',$data)->render();
        //Arr::pluck($array, 'developer.name', 'developer.id');
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create()
    {
        return view('cms::create');
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required',
            'meta_keywords' => 'required',
            'meta_description' => 'required',
            'slug' => 'alpha_dash',
            'content' => 'required',
            'template_name' => 'required',
            'parent_id' => 'required',
        ]);

        $data['status'] = 1;
        $data['slug'] = empty($request->input('slug')) ? Str::slug($data['title']) : Str::slug($data['slug']);
        $data['page_type'] = $request->input('page_type');
        $data['created_by'] = auth('admin')->user()->id;
        $data['updated_by'] = auth('admin')->user()->id;

        $cms = Page::create($data);
        return [
            'status' => 1,
            'cms'=>$cms
        ];
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show(Page $page)
    {
        return $page;
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit(Page $page)
    {
        return $page;
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, Page $page)
    {
        $data = $request->validate([
            'title' => 'required',
            'meta_keywords' => 'required',
            'meta_description' => 'required',
            'slug' => 'required|alpha_dash',
            'content' => 'required',
            'template_name' => 'required',
            'parent_id' => 'required',
        ]);
        $page->title = $data['title'];
        $page->meta_keywords = $data['meta_keywords'];
        $page->meta_description = $data['meta_description'];
        $page->slug = $data['slug'];
        $page->content = $data['content'];
        $page->template_name = $data['template_name'];
        $page->parent_id = $data['parent_id'];
        $page->status = 1;
        $page->page_type = $request->input('page_type');
        $page->updated_by = auth('admin')->user()->id;

        $stat = $page->save();
        return ['status'=>$stat];
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }

    public function ajax_list(Request $request){
        $columns = ['title', 'slug','page_type','created_at'];

        // $total = AdminAuth::count();

        // initiate the query here
        $query = Page::select('id','title', 'slug','page_type','created_at');

        //get the result from trait
        $result = $this->get_data_query($query,$columns);

        $data = [];
        foreach ($result['result'] as $key => $value) {
            $row = [];
            $row[] = $value->title;
            $row[] = $value->slug;
            $row[] = $value->page_type;
            $row[] = $value->created_at;
            $row[] = "
            <a href='javascript:void(0);' onclick='crud_view({$value->id})' class='btn btn-sm btn-info'><i class='fa fa-eye'></i></i> View</a>
            <a href='javascript:void(0);' onclick='crud_edit({$value->id})' class='btn btn-sm btn-primary'><i class='fa fa-pen'></i></i> Edit</a>
            <a href='javascript:void(0);' onclick='crud_delete({$value->id})' class='btn btn-sm btn-danger'><i class='fa fa-trash'></i></i> Delete</a>
            ";
            $data[] = $row;
        }


        return [
            "draw"=>intval($request->input('draw')),
            "recordsTotal"=>intval($result['total_results']),
            "recordsFiltered"=>intval($result['total_results']),
            "data"=>$data
        ];

    }

    // custom datatable filters - controller specific - to be used with the GetDatatables Trait
    protected function get_filters($query){
        if(request()->input('is_super')!=''){
            $query = $query->where('is_super',request()->input('is_super'));
        }
        if(request()->input('page_type')!=''){
            $query = $query->where('page_type',request()->input('page_type'));
        }
        return $query;
    }

}
