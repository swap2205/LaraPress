<?php

return [
    'name' => 'CMS'
];
