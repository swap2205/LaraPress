<?php

namespace Modules\CMS\Entities;

use Illuminate\Database\Eloquent\Model;

class Page extends Model
{
    protected $fillable = [
        'title',
        'meta_keywords',
        'meta_description',
        'slug',
        'page_type',
        'content',
        'template_name',
        'featured_image',
        'status',
        'parent_id',
        'created_by',
        'updated_by'
    ];

    public static $form_fields = [
        ['name'=>'title','label'=>'Title','element'=>'input', 'type'=>'text'],
        ['name'=>'meta_keywords','label'=>'Meta Keywords', 'element'=>'input', 'type'=>'text'],
        ['name'=>'meta_description','label'=>'Meta Description' ,'element'=>'input', 'type'=>'text'],
        ['name'=>'slug','label'=>'Slug', 'type'=>'text','element'=>'input'],
        // ['name'=>'page_type','label'=>'Page Type','type'=>'hidden','element'=>'input'],
        ['name'=>'content','label'=>'Content', 'element'=>'textarea'],
        ['name'=>'template_name','label'=>'Template Name','element'=>'select', 'values'=>['default'=>'Default', 'sidebar'=>'Sidebar', 'sidebar_right'=>'Sidebar Right']],
        ['name'=>'featured_image','label'=>'Featured Image', 'type'=>'file','element'=>'input'],
        ['name'=>'status','label'=>'Status', 'element'=>'select','values'=>['Disable','Active']],
        'parent_id'=>['name'=>'parent_id','label'=>'Parent' ,'element'=>'select','values'=>['Disable','Active']],
    ];
}
